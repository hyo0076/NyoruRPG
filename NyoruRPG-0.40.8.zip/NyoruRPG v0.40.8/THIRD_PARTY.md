# References and notices

This engine is newly authored for the user's supplied Universal Narrative RPG v2.1 specification. The Story Dice validation, unbiased d100 rejection boundary, queue/scope concepts and RisuAI module packaging were consulted. The LongMemory 0.21.0 independent-provider, source-selection and preview/apply patterns were consulted. LongMemory itself, its tokenizer/PDF/embedding dependencies and memory hooks are not bundled or required.

`vendor/rpack_map.bin` is a copy of the existing workspace's RPack mapping used to encode/decode the Risu module container. The accompanying notices are preserved verbatim in `vendor/RPACK-LICENSE` and `vendor/RPACK-LICENSE-MIT`. Packaging validates a complete round trip. No RPack executable is loaded at runtime.

The original references remain outside this project, unchanged. Included source-document copies are the user's supplied requirements and reference notes. No rights are inferred for unrelated LongMemory dependencies.

Node.js is required for development/builds. Optional browser QA uses an externally installed Playwright/Chrome; neither is bundled into the distributable plugin.

The 0.30.12 build uses Acorn 8.15.0 (MIT) to read local module dependencies and Terser 5.44.0 (BSD-2-Clause) to remove JavaScript comments and whitespace. They are development dependencies pinned in package.json and pnpm-lock.yaml, not plugin runtime dependencies. Their package license files remain in node_modules; the generated plugin does not embed these tools.

## Project Zirkott reference

The dedicated Zirkott rulebook uses the user-supplied 프로젝트지르코트_export.json (chara_card_v3, Project Zirkott / 프로젝트:지르코트, version 1.8, creator 에벨레). src/zirkott-data.js contains selected region topology, regional descriptions and boss mechanical reference text from that supplied card. Original images, executable Lua/scripts, presentation markup and narrative instructions are not bundled. Radiation rates, transit time/cost, survival rates and unspecified economic values are newly authored editable game defaults, not claimed as original canon or physical/medical measurements. Detailed boss residences take precedence over inconsistent list headings; self-links in route lists are omitted. Attribution does not assert a license for public redistribution; this release remains local under the user's no-upload instruction.
