'use strict';
const fs = require('node:fs');
const path = require('node:path');
const sourceDir = __dirname;
const light = true;
const out = sourceDir;
const root = path.resolve(sourceDir, '../..');
fs.mkdirSync(out, {recursive:true});
const read = name => fs.readFileSync(path.join(sourceDir, name), 'utf8').replace(/\r\n/g, '\n');
const write = (name, content) => fs.writeFileSync(path.join(out, name), content, 'utf8');
const writeSource = (name, content) => fs.writeFileSync(path.join(sourceDir, name), content, 'utf8');
const esc = v => String(v).replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
// Preserve the light palette from the previous introduction.
const C = light ? {
  bg:'#faf7ef', panel:'#fffdf7', raised:'#f5f0e6', text:'#403d39', title:'#403d39', muted:'#71695f', line:'#d8cebf', pink:'#3b627d', gold:'#3b627d', mint:'#3e6249',
  primary:'#f4bfbf', primaryText:'#403d39', canvas:'#f4eddf',
  hero:'linear-gradient(125deg,#f4bfbf,#fffaf0,#e2edf2)', quote:'linear-gradient(120deg,#e2edf2,#fffdf7)', book:'linear-gradient(90deg,#f4eddf,#fffdf7)',
  chip:'#e2edf2', chipLine:'#8caebf', chipText:'#3b627d',
  roll:'linear-gradient(125deg,#e6efdf,#fffdf7)', rollLine:'#a3b795', rollLabel:'#3e6249', rollText:'#403d39', rollNumber:'#3e6249', rollResult:'#3b627d', rollHighlight:'#fffdf7'
} : {
  bg:'#171d27', panel:'#202936', raised:'#283444', text:'#e0e3e8', title:'#fff5e5', muted:'#bdc8d8', line:'#465267', pink:'#ffc0b4', gold:'#f2d49b', mint:'#a8dfcc',
  primary:'#ffc0b4', primaryText:'#291c29', canvas:'#10151d',
  hero:'linear-gradient(125deg,#3b2e43,#1f3340,#172530)', quote:'linear-gradient(120deg,#303140,#252d3c)', book:'linear-gradient(90deg,#283444,#202936)',
  chip:'#283746', chipLine:'#586174', chipText:'#a8dfcc',
  roll:'linear-gradient(125deg,#213b35,#263b47)', rollLine:'#64877b', rollLabel:'#b8dccb', rollText:'#e1eee7', rollNumber:'#c5f4d9', rollResult:'#f0dfac', rollHighlight:'#84a794'
};
const assets = 'https://raw.githubusercontent.com/hyo0076/NyoruRPG/main/docs/post-assets/';
// Public assets are also included locally for the saved preview.
const cardAssets = assets + 'cards/';
const style = {
  p:`margin:0 0 16px;color:${C.text};font-size:16px;line-height:1.9;`,
  h3:`margin:27px 0 13px;color:${C.gold};font-size:21px;line-height:1.55;`,
  h4:`margin:22px 0 11px;color:${C.title};font-size:18px;line-height:1.65;`
};
const cardSource=path.join(sourceDir,'카드');
const cardIndex=JSON.parse(fs.readFileSync(path.join(cardSource,'manifest.json'),'utf8'));
const source=read('본문.md');
const books=[...read('룰북.md').matchAll(/^:::rulebook ([^\n]+)\n([\s\S]*?)^:::end/gm)].map(m=>{
  const [id,title,label,color,tagline]=m[1].split('|').map(v=>v.trim());
  return {id,title,label,color,tagline,body:m[2].trim()};
});
const sections=[...source.matchAll(/^## (.+)$/gm)].map((m,i)=>({title:m[1],id:'section-'+(i+1),number:String(i+1).padStart(2,'0')}));
const shots=[];
function inline(s){
  const tokens=[],keep=v=>'\u0000'+(tokens.push(v)-1)+'\u0000';
  s=s.replace(/`([^`]+)`/g,(_,v)=>keep('<span style="font-family:Consolas,monospace;color:'+C.gold+';">'+esc(v)+'</span>'));
  s=s.replace(/\[([^\]]+)\]\(([^\s)]+)\)/g,(_,label,url)=>{
    if(!/^(https:\/\/|#)/.test(url))return label;
    return keep('<a href="'+esc(url)+'"'+(url.startsWith('#')?'':' target="_blank" rel="noopener noreferrer"')+' style="text-decoration:underline;"><span style="color:'+C.pink+';">'+esc(label)+'</span></a>');
  });
  return esc(s).replace(/\*\*(.+?)\*\*/g,'<strong style="color:'+C.title+';">$1</strong>').replace(/\u0000(\d+)\u0000/g,(_,i)=>tokens[+i]);
}
function fold(title,body,color=C.gold,open=false){
  return '<details'+(open?' open':'')+' style="margin:14px 0;border:1px solid '+C.line+';background:'+C.panel+';"><summary style="padding:17px 18px;color:'+color+';font-size:18px;font-weight:700;line-height:1.6;">'+esc(title)+'<span style="display:inline-block;margin-left:10px;color:'+C.muted+';font-size:12px;font-weight:400;">펼치기 / 접기</span></summary><div style="padding:5px 5% 17px;border-top:1px solid '+C.line+';">'+body+'</div></details>';
}
function shot(line){
  const [title,caption]=line.slice(8).split('|').map(v=>v.trim()),n=String(shots.length+1).padStart(2,'0');
  shots.push({n,title,caption});
  return '<div style="margin:24px 0;border-top:2px solid '+C.line+';padding-top:13px;"><p style="margin:0 0 7px;color:'+C.gold+';font-size:13px;">이미지 '+n+' · '+esc(title)+'</p><table style="width:100%;border:0;border-collapse:collapse;"><tbody><tr style="border:0;"><td style="height:96px;border:1px dashed '+C.line+';background:'+C.bg+';"></td></tr></tbody></table><p style="margin:8px 0 0;color:'+C.muted+';font-size:13px;line-height:1.7;">'+esc(caption)+'</p></div>';
}
function table(rows){
  const [head,...data]=rows;
  return '<div style="margin:17px 0;">'+data.map(row=>'<div style="margin-bottom:9px;padding:13px 15px;border-left:2px solid '+C.line+';background:'+C.raised+';"><p style="margin:0 0 7px;color:'+C.title+';font-weight:700;line-height:1.7;">'+inline(row[0])+'</p>'+row.slice(1).map((cell,i)=>'<p style="margin:4px 0;color:'+C.text+';font-size:15px;line-height:1.8;">'+(row.length>2?'<span style="color:'+C.mint+';">'+inline(head[i+1]||'')+' · </span>':'')+inline(cell)+'</p>').join('')+'</div>').join('')+'</div>';
}
function md(text,{top=false}={}){
  const lines=text.split('\n');let html='';
  for(let i=0;i<lines.length;){
    const s=lines[i].trim();if(!s){i++;continue;}
    if(s===':::features'){html+=featureStories();i++;continue;}
    if(s===':::rulebooks'){html+=rulebooks();i++;continue;}
    if(s===':::guides'){html+=guides();i++;continue;}
    if(s===':::manual'){html+=manual();i++;continue;}
    if(s===':::optional'){html+=fold('선택 기능 전체 · 지원 룰북과 세부 설정',md(read('선택-기능-상세.md')));i++;continue;}
    if(s===':::themes'){html+=themes();i++;continue;}
    if(s.startsWith(':::shot ')){html+=shot(s);i++;continue;}
    if(s.startsWith(':::fold ')){
      const title=s.slice(8),block=[];i++;while(i<lines.length&&lines[i].trim()!==':::endfold')block.push(lines[i++]);i++;
      html+=fold(title,md(block.join('\n')));continue;
    }
    if(s===':::roll'){html+=roll();i++;continue;}
    const h=/^(#{1,4}) (.+)$/.exec(s);
    if(h){
      const level=h[1].length,title=h[2],section=top&&level===2?sections.find(v=>v.title===title):null;
      if(section)html+='<div id="'+section.id+'" style="margin:45px 0 24px;padding-top:24px;border-top:1px solid '+C.line+';"><p style="margin:0 0 7px;color:'+C.pink+';font-size:12px;letter-spacing:2px;">'+section.number+' / NYORU RPG</p><h2 style="margin:0;color:'+C.title+';font-size:28px;line-height:1.5;">'+inline(title)+'</h2></div>';
      else html+='<h'+Math.max(3,level)+' style="'+style['h'+Math.max(3,level)]+'">'+inline(title)+'</h'+Math.max(3,level)+'>';
      i++;continue;
    }
    if(s.startsWith('```')){const b=[];i++;while(i<lines.length&&!lines[i].trim().startsWith('```'))b.push(lines[i++]);i++;html+='<pre style="margin:16px 0;padding:12px;background:'+C.bg+';border:1px solid '+C.line+';color:'+C.gold+';font-size:14px;line-height:1.8;white-space:pre-wrap;">'+esc(b.join('\n'))+'</pre>';continue;}
    if(s.startsWith('|')){
      const rows=[];while(i<lines.length&&lines[i].trim().startsWith('|')){const row=lines[i++].trim().slice(1).replace(/\|$/,'').split('|').map(x=>x.trim());if(!row.every(x=>/^:?-+:?$/.test(x)))rows.push(row);}html+=table(rows);continue;
    }
    if(/^[-*] /.test(s)||/^\d+\. /.test(s)){
      const ordered=/^\d+\. /.test(s),re=ordered?/^\d+\. /:/^[-*] /,tag=ordered?'ol':'ul',items=[];
      while(i<lines.length&&re.test(lines[i].trim()))items.push(lines[i++].trim().replace(re,''));
      html+='<'+tag+' style="margin:12px 0 20px;padding-left:23px;color:'+C.text+';font-size:16px;line-height:1.9;">'+items.map(x=>'<li style="margin-bottom:9px;">'+inline(x)+'</li>').join('')+'</'+tag+'>';continue;
    }
    if(s.startsWith('>')){
      const b=[];while(i<lines.length&&lines[i].trim().startsWith('>'))b.push(lines[i++].trim().replace(/^>\s?/,''));
      html+='<div style="margin:21px 0;padding:18px 19px;border-left:3px solid '+C.pink+';background:'+C.quote+';color:'+C.title+';font-size:17px;line-height:1.95;">'+b.map(x=>x?inline(x):'<br>').join('<br>')+'</div>';continue;
    }
    if(/^---+$/.test(s)){html+='<hr style="border:0;border-top:1px solid '+C.line+';margin:25px 0;">';i++;continue;}
    const p=[s];i++;while(i<lines.length&&lines[i].trim()&&!/^(#|:::|\||>|```|[-*] |\d+\. )/.test(lines[i].trim()))p.push(lines[i++].trim());
    html+='<p style="'+style.p+'">'+inline(p.join(' '))+'</p>';
  }
  return html;
}
function rulebooks(){return books.map((b,i)=>'<details id="rulebook-'+b.id+'" style="margin:21px 0;background:'+C.panel+';border:1px solid '+C.line+';border-top:3px solid '+b.color+';"><summary style="list-style:none;color:'+C.title+';"><img src="'+assets+'rulebook-'+b.id+'.png" alt="'+esc(b.title)+' 룰북 배너" width="1200" height="300" style="width:100%;max-width:100%;height:auto;vertical-align:top;"><div style="padding:15px 5%;background:'+C.book+';"><span style="color:'+C.muted+';font-size:12px;letter-spacing:1px;">'+String(i+1).padStart(2,'0')+' · '+esc(b.label)+'</span><p style="margin:5px 0;color:'+C.title+';font-size:23px;font-weight:700;line-height:1.5;">'+esc(b.title)+'</p><span style="color:'+C.muted+';font-size:14px;">'+esc(b.tagline)+'</span><p style="margin:9px 0 0;color:'+C.gold+';font-size:13px;">＋ 플레이 예시 · 기능 · 설정 펼치기 / 접기</p></div></summary><div style="padding:4px 5% 20px;border-top:1px solid '+C.line+';">'+md(b.body)+'</div></details>').join('');}
function featureStories(){return [...read('새로운-플레이.md').matchAll(/^## (.+)\n([\s\S]*?)(?=^## |$(?![\s\S]))/gm)].map(m=>fold(m[1],md(m[2]))).join('');}
function guides(){return [...read('사용법.md').matchAll(/^## (.+)\n([\s\S]*?)(?=^## |$(?![\s\S]))/gm)].map(m=>fold(m[1],md(m[2]))).join('');}
function manual(){const raw=read('효과-편집-상세.md'),start=raw.search(/^## /m);return md(raw.slice(0,start))+[...raw.slice(start).matchAll(/^## (.+)\n([\s\S]*?)(?=^## |$(?![\s\S]))/gm)].map(m=>fold(m[1],md(m[2]),C.mint)).join('');}
function cardImage(file,label){return '<img src="'+cardAssets+file+'" alt="'+esc(label)+'" style="display:block;width:100%;max-width:100%;height:auto;margin:14px auto;">';}
function themes(){
  const descriptions={cartoon:'큰 숫자와 전위적인 도형으로 판정 결과를 시원하게 보여 줍니다.',fantasy:'남색 마도서 위에 룬과 별빛이 새겨집니다.',romance:'꽃과 편지의 부드러운 분위기를 담았습니다.',cyber:'전자회로 문양과 보색의 글자로 결과를 강조합니다.',murim:'먹물 번짐, 낙관과 산수의 여백을 담은 서첩입니다.',tactical:'모서리의 사용감과 전술 표식이 남은 야전 단말기입니다.'};
  return '<p style="'+style.p+'">같은 판정을 여섯 가지 테마로 비교해 보세요. 룰북과 카드 테마는 별도로 고를 수 있습니다.</p>'
    +cardImage(cardIndex.overview,'여섯 카드 테마 비교 · 모두 72 vs 45 성공, HP 피해 28')
    +'<p style="margin:8px 0 18px;color:'+C.muted+';font-size:13px;line-height:1.8;">기존 소개글의 카드 예시 이미지를 함께 실었습니다. 실제 사용자 채팅 캡처는 아닙니다. 아래 테마를 펼치면 판정·행동 게이지·턴테이블·성장 카드를 크게 볼 수 있습니다.</p>'
    +cardIndex.samples.map(sample=>fold(sample.name+' · 카드 자세히 보기','<p style="'+style.p+'">'+esc(descriptions[sample.id])+'</p>'+cardImage(sample.file,sample.name+'의 판정·행동 게이지·턴테이블·성장 카드'))).join('');
}
function roll(){return '<div style="margin:24px 0;padding:22px;background:'+C.roll+';border:1px solid '+C.rollLine+';box-shadow:inset 0 1px 0 '+C.rollHighlight+';"><p style="margin:0 0 14px;color:'+C.rollLabel+';font-size:12px;letter-spacing:1px;">판정과 변화 · 설명용 표시 예시</p><p style="margin:0;color:'+C.rollText+';font-size:17px;">당신의 마지막 일격</p><div style="margin:8px 0 14px;color:'+C.rollNumber+';"><strong style="font-size:56px;line-height:1.2;">85</strong><span style="font-size:20px;"> vs 45</span><strong style="display:inline-block;margin-left:20px;color:'+C.rollResult+';font-size:29px;">성공</strong></div><p style="margin:0;padding-top:11px;border-top:1px solid '+C.rollLine+';color:'+C.rollText+';font-size:15px;line-height:1.8;">HP 피해 42 · MP 소모 8<br>명중 → 냉기 누적 → 동결 조건 확인</p></div>';}
function cta(label,url,primary=false){return '<a href="'+url+'"'+(url.startsWith('#')?'':' target="_blank" rel="noopener noreferrer"')+' style="text-decoration:none;"><span style="display:inline-block;margin:5px 8px 5px 0;padding:12px 17px;border:1px solid '+(primary?C.primary:C.line)+';background:'+(primary?C.primary:C.raised)+';"><span style="color:'+(primary?C.primaryText:C.title)+';font-weight:700;font-size:15px;">'+esc(label)+'</span></span></a>';}
const hero='<div style="padding:33px 6% 30px;background:'+C.hero+';border-bottom:1px solid '+C.line+';"><p style="margin:0 0 12px;color:'+C.pink+';font-size:12px;letter-spacing:2px;">RISUAI · RPG PLUGIN · 0.40.0</p><h1 style="margin:0 0 15px;color:'+C.title+';font-size:44px;line-height:1.2;">NyoruRPG</h1><p style="margin:0 0 20px;color:'+C.title+';font-size:21px;font-weight:700;line-height:1.65;">리수 세상의 모든 봇에<br>DICE를 돌릴 수 있을 때까지.</p><p style="margin:0 0 21px;color:'+C.text+';font-size:16px;line-height:1.9;">어제 도망쳤던 늑대를 오늘은 쓰러뜨리고,<br>나를 지켜보던 시선이 내 편이 되는 이야기.</p><div>'+['8가지 룰북','취향대로 고르는 규칙','6가지 카드 테마'].map(t=>'<span style="display:inline-block;margin:0 6px 7px 0;padding:5px 9px;background:'+C.chip+';border:1px solid '+C.chipLine+';color:'+C.chipText+';font-size:13px;">'+t+'</span>').join('')+'</div><p style="margin:17px 0 11px;color:'+C.muted+';font-size:14px;">뇨루가 무급으로 일합니다.<br><span style="color:'+C.pink+';">“냥? 그게 무슨 소리냥???”</span></p><div>'+cta('이런 플레이 어때요?','#section-2',true)+cta('처음 설치하기','#section-7')+cta('0.40.0 다운로드','https://github.com/hyo0076/NyoruRPG/releases/tag/v0.40.0')+'</div><p style="margin:14px 0 0;color:'+C.muted+';font-size:13px;">플러그인만 업데이트. 모듈 v1은 그대로</p></div>';
const toc='<div style="margin:0 0 20px;padding:13px 0;border-bottom:1px solid '+C.line+';">'+sections.map(s=>'<a href="#'+s.id+'" style="text-decoration:none;"><span style="display:inline-block;margin:5px 13px 5px 0;color:'+C.muted+';font-size:13px;">'+s.number+' '+esc(s.title)+'</span></a>').join('')+'</div>';
const rawBody='<div style="max-width:860px;margin:0 auto;background:'+C.bg+';border:1px solid '+C.line+';font-family:Malgun Gothic,Apple SD Gothic Neo,sans-serif;color:'+C.text+';font-size:16px;line-height:1.9;">'+hero+'<div style="padding:22px 5% 35px;">'+toc+md(source,{top:true})+'</div></div>';
// The supplied Arca guide keeps light surfaces as images and protects inline ink colors.
// This is a paste compatibility precaution, not a live Arca rendering confirmation.
function lightModeHTML(html){
  return html.replace(/style="([^"]*)"/g,(_,css)=>{
    css=css.replace(/(^|;)background:(#[0-9a-f]{3,8});/gi,(_,prefix,color)=>prefix+'background:linear-gradient(0deg,'+color+','+color+');');
    if(/(^|;)color:/.test(css))css+='background-color:rgba(0,0,0,0.004);';
    return 'style="'+css+'"';
  });
}
const body=light?lightModeHTML(rawBody):rawBody;
write('NyoruRPG-소개글-HTML붙여넣기.txt',body);
write('NyoruRPG-소개글.html','<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NyoruRPG 0.40.0 · '+(light?'라이트 · ':'')+'소개와 사용법</title></head><body style="margin:0;padding:12px 6px;background:'+C.canvas+';">'+body.replaceAll(cardAssets,'카드/').replaceAll(assets,'배너/')+'</body></html>');
write('스크린샷-첨부목록.txt',shots.map(s=>s.n+'. '+s.title+'\n'+s.caption).join('\n\n')+'\n');
const fullSource=source.replace(/^## (.+)$/gm,(line,title)=>'<a id="'+sections.find(s=>s.title===title).id+'"></a>\n\n'+line).replace(':::features',read('새로운-플레이.md')).replace(':::rulebooks',books.map(b=>'### '+b.title+'\n\n'+b.body).join('\n\n')).replace(':::guides',read('사용법.md')).replace(':::manual',read('효과-편집-상세.md')).replace(':::optional',read('선택-기능-상세.md'))
  .replace(':::roll','> 설명용 판정 예시: 85 vs 45 · 성공 · HP 피해 42 · MP 소모 8 · 명중과 냉기 누적, 동결 조건 확인.')
  .replace(':::themes','카드 테마: 카툰 / 판타지·밤빛 마도서 / 로맨스 / 사이버 / 무림 / 택티컬.')
  .replace(/^:::fold (.+)$/gm,'### $1').replace(/^:::endfold\s*$/gm,'').replace(/^:::shot (.+?) \| (.+)$/gm,'> 이미지 자리: $1 — $2');
write('NyoruRPG-소개글-원문.md','# NyoruRPG 0.40.0\n\n'+fullSource);
if(light)write('게시-안내.md',read('게시-안내.md'));
write('카드-이미지-첨부목록.txt','게시용 HTML은 GitHub의 공개 카드 이미지 주소를 사용합니다. 아카라이브 자체 첨부를 쓰려면 아래 PNG를 올린 뒤 해당 img의 src를 바꾸세요.\n이전 소개글에서 제작한 카드 스타일 예시이며 실제 사용자 채팅 캡처가 아닙니다.\n\n'+[cardIndex.overview,...cardIndex.samples.map(s=>s.file)].map(file=>'카드/'+file).join('\n')+'\n');
const docs=path.join(root,'docs');
// A downloaded introduction folder can rebuild itself without the development repo.
if(fs.existsSync(path.join(root,'src','version.js'))&&fs.existsSync(docs)){
fs.writeFileSync(path.join(docs,'NyoruRPG-소개글.html'),fs.readFileSync(path.join(out,'NyoruRPG-소개글.html'),'utf8').replaceAll('src="배너/','src="post-assets/').replaceAll('src="카드/','src="post-assets/cards/'),'utf8');
fs.writeFileSync(path.join(docs,'NyoruRPG-소개글-HTML붙여넣기.txt'),body,'utf8');
fs.writeFileSync(path.join(docs,'NyoruRPG-소개글-보충본.md'),'# NyoruRPG 0.40.0 소개와 사용법\n\n'+fullSource,'utf8');
fs.copyFileSync(path.join(out,'스크린샷-첨부목록.txt'),path.join(docs,'스크린샷-첨부목록.txt'));
fs.copyFileSync(path.join(out,'게시-안내.md'),path.join(docs,'NyoruRPG-소개글-게시안내.md'));
const publicCards=path.join(docs,'post-assets','cards');
fs.mkdirSync(publicCards,{recursive:true});
for(const name of [cardIndex.overview,...cardIndex.samples.map(s=>s.file),'manifest.json'])fs.copyFileSync(path.join(cardSource,name),path.join(publicCards,name));
}
console.log(JSON.stringify({version:'0.40.0',theme:light?'light':'dark',rulebooks:books.length,screenshotSlots:shots.length,output:out}));
