'use strict';
const base=new URL('./',location.href).href.replace(/\/$/,'');
document.getElementById('base-url').textContent=base;
document.getElementById('mcp-url').textContent=base+'/mcp';
const providerSettings=document.getElementById('provider-settings'),choice=document.getElementById('publisher-choice');
function selectPublisher(){document.getElementById('provider-url').textContent=choice.value?base+'/mcp/'+encodeURIComponent(choice.value):'';}
choice.addEventListener('change',selectPublisher);
function clearResults(){
  providerSettings.hidden=true;choice.replaceChildren();selectPublisher();
  document.getElementById('publishers').replaceChildren();
}
let lookup=0,activeRequest;
document.getElementById('consumer-key').addEventListener('input',()=>{
  lookup++;activeRequest?.abort();clearResults();
  document.querySelector('#status-form button').disabled=false;
  document.getElementById('status').textContent='키를 입력한 뒤 도구·주소 확인을 누르세요.';
});
document.getElementById('status-form').addEventListener('submit',async event=>{
  event.preventDefault();const status=document.getElementById('status'),list=document.getElementById('publishers'),button=event.target.querySelector('button');
  const key=document.getElementById('consumer-key').value.trim();
  if(!key){clearResults();status.textContent='실행창의 Consumer key 값을 입력하세요.';return;}
  const previous=choice.value,request=++lookup,controller=new AbortController();
  activeRequest?.abort();activeRequest=controller;
  const timer=setTimeout(()=>controller.abort(),10000);
  button.disabled=true;status.textContent='등록된 도구를 확인하고 있습니다.';clearResults();
  try{
    const response=await fetch(base+'/bridge/v1/status',{headers:{Authorization:'Bearer '+key},signal:controller.signal,cache:'no-store'});
    if(!response.ok)throw new Error(response.status===401?'Consumer key가 맞지 않습니다. Publisher key가 아닌 호출용 키를 넣어 주세요.':'도구 목록을 읽지 못했습니다. (HTTP '+response.status+')');
    const data=await response.json();
    if(!Array.isArray(data.publishers))throw new Error('중계기 응답을 읽지 못했습니다. 중계기 주소를 확인하세요.');
    if(request!==lookup)return;
    const online=data.publishers.filter(p=>p.online&&p.tools>0);
    status.textContent=online.length?'확인 완료 · 연결 중인 그룹 '+online.length+'개 · 도구 '+online.reduce((sum,p)=>sum+p.tools,0)+'개':'등록된 그룹은 있지만 연결 중인 도구가 없습니다. 해당 플러그인을 열고 다시 연결하세요.';
    for(const publisher of data.publishers){
      const row=document.createElement('p');
      row.textContent=publisher.name+' · '+(publisher.online?'중계기에 연결됨':'연결 끊김')+' · 도구 '+publisher.tools+'개';list.append(row);
    }
    for(const publisher of online){
      const option=document.createElement('option');option.value=publisher.id;
      option.textContent=publisher.name+' ('+publisher.id+') · 도구 '+publisher.tools+'개';choice.append(option);
    }
    if(online.some(p=>p.id===previous))choice.value=previous;
    selectPublisher();providerSettings.hidden=!online.length;
    if(!data.publishers.length)status.textContent='등록된 도구가 없습니다. 사용할 플러그인에 기본 주소와 Publisher key를 넣고 연결한 뒤 다시 확인하세요.';
  }catch(error){if(request===lookup){clearResults();status.textContent=controller.signal.aborted?'10초 안에 응답을 받지 못했습니다. 중계기 실행창이 열려 있는지 확인하세요.':error instanceof TypeError?'중계기에 접속하지 못했습니다. 중계기 실행창이 열려 있는지 확인하세요.':error.message||'도구 목록을 읽지 못했습니다.';}}
  finally{clearTimeout(timer);if(request===lookup){activeRequest=null;button.disabled=false;}}
});
document.querySelectorAll('[data-copy]').forEach(button=>button.addEventListener('click',async()=>{
  const source=document.getElementById(button.dataset.copy),value=source.textContent;
  if(!value)return;
  const status=document.getElementById('copy-status');
  try{await navigator.clipboard.writeText(value);status.textContent='주소를 복사했습니다.';}
  catch{const range=document.createRange();range.selectNodeContents(source);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);status.textContent='자동 복사를 사용할 수 없어 주소를 선택했습니다. 선택된 주소를 복사하세요.';}
}));
window.addEventListener('pagehide',()=>{
  lookup++;activeRequest?.abort();document.getElementById('consumer-key').value='';clearResults();
  document.querySelector('#status-form button').disabled=false;document.getElementById('status').textContent='Consumer key를 입력하고 도구·주소 확인을 누르세요.';
});
