# MCP 기능 연결 점검 · 2026-09-28

## 결론

도구를 묶는 과정에서 실제 연결 누락이 있었습니다. 실행 코드가 남아 있어도 메인 AI가 부를 수 없거나 필요한 입력을 전달할 수 없으면 사용 가능한 기능이 아닙니다. 이번에는 공개 목록, 동작별 인수, 준비·실행 코드, 결과의 후속 안내를 함께 확인했습니다.

다만 최근의 모든 호출 누락이 도구 개수 때문에 생겼다는 증거는 없습니다. 0.15.0과 수정 전 0.17.2의 공개 수는 같은 모드에서 같았습니다. 초기 등록 도구 누락, 이번에 찾은 연결 누락, 0.17.1의 잘못된 자동 턴 제한, 메인 AI가 호출 없이 서술한 경우를 구분해야 합니다.

## 확인한 원본

- 11개 구조: `backups/before-gameplay-0.7.0/`의 0.6.5 소스.
- 초기 통합: `backups/before-nyoru-0.8.0/`의 0.7.0 소스.
- 0.15 계열: `backups/before-structure-0.16.0/`의 0.15.1 소스. 앞선 점검에서 핵심 명세·실행·지침 파일이 배포 0.15.0과 같은 것을 확인했습니다.
- 최근 자동 턴 원형: `backups/before-call-flow-0.17.1/`의 0.17.0.
- 이번 수정 직전: `backups/before-tool-route-audit-0.17.3/`의 0.17.2.

0.7.0의 native 모드는 5개로 줄었습니다. 이후 헌터 성장, 등록 도구 등이 추가되어 헌터가 7개가 됐습니다. 한 번의 11→7 변경만 있었던 것은 아닙니다. 0.12.7까지 등록을 지시하면서 `rpg_registry`를 공개하지 않은 문제는 0.13.0에서 이미 수정됐습니다.

## 이번에 확인하고 수정한 문제

| 문제 | 수정 전 연결 | 0.17.3 |
| --- | --- | --- |
| 공통 d100의 사건 경험치 | `native-rpg.progress`의 award는 있으나 native 공개 목록에서 progress 전체 제외 | award 공개. 헌터 전용 배분과 공통 사용자 배분은 구분 유지 |
| 대상이 있는 비전투 행동 | 미등록 행동에 targets가 있으면 combat:false여도 기술 준비. 별도 check는 비공개 | check 공개. 비전투 일반 행동과 명시한/저장된 기술 구분. 대상·의도를 판정에 전달 |
| 다중 미결 공격에 대한 반응 | 내부 reaction은 threatId를 받지만 act/명명 반응에는 입력이 없음. 계속 경로는 첫 공격 선택 | 공개 입력→준비 계획→실제 reaction까지 threatId 전달. 모호하면 반응할 공격 선택 필요 |
| 소모품·재장전·소환 뒤 턴 | 행동을 소모하지만 자동 턴 종료는 combat.action/reaction에만 있음. 대체 계속 경로 안내 없음 | 현재 행동 소모 시 next에 동일 인물의 계속 경로 안내 |
| 기술 숙련 훈련 | 내부 train은 있으나 native 등록 도구에서는 제외 | train 공개, 저장된 성장 정책 유지. 지급 전후 수치와 적용 여부 반환 |

단순 비전투 판정에서는 상대의 공격 연계까지 준비하지 않습니다. 알려진 기술은 실제 저장 비용·효과 경로를 사용하며, 새 기술임을 명시하려면 act의 skill에도 이름을 줍니다. 진행 중인 전투를 check로 우회하지 않습니다.

## 기존 11개 도구의 기능별 대응

아래는 코드의 연결 확인입니다. 실제 모델 호출 성공을 뜻하지 않습니다. 내부 전투 도구 등은 예전 저장 세계에서는 계속 공개되며, native 공통/헌터에서는 통합 경로를 사용합니다.

| 기존 도구·명령 | 현재 연결과 판정 |
| --- | --- |
| play: skill, prepare_skill | act가 저장 기술을 찾거나 처음 필요한 기술을 준비한 뒤 실행. 준비만 하기와 실제 사용은 내부에서 구분 |
| play: obtain, refresh | 같은 명령 유지. 실제 획득과 명시적인 기술/원본 수치 수정 |
| play: check | **다시 공개.** 내부 `rpg_check.resolve`로 고정 능력치·난이도 계산 |
| progress: award | **공통 d100에 다시 공개.** 헌터에서는 이미 공개. 사건별 중복 지급 방지 유지 |
| bootstrap: status, refresh | 구축 화면·현재 상태 조회가 담당. 구성된 native 세계에서 구축 도구를 게임 행동으로 공개하지 않음 |
| state: last_results, summary, growth, actor, skill, inventory, equipment, wallet, combat, exploration, action_result | 모든 명령 유지. 조회는 실행·회복·보상 대신이 아님 |
| combat: start, join | act의 실제 participants와 대상에서 시작·난입. 관전자는 제외, 일반 선공/기습 유지 |
| combat: action basic_attack/skill | act 공격/기술 → 엔진 계산 → 주변 NPC 자동 턴. 명중·비용·피해·연계·상태 효과 유지 |
| combat: action wait | act 대기 → 행동 소모·턴 종료 |
| combat: action reload | inventory.reload. **행동을 소모한 뒤 계속 안내 보강** |
| combat: action defend/evade | 이전 엔진부터 독립 행동은 거부하고 도착한 공격의 반응으로 처리. 새 누락으로 분류하지 않음 |
| combat: reaction | act 방어/회피/반응 기술 또는 계속의 reactions. **threatId 입력 복구**. 반응 없음도 reactions의 none으로 지정 |
| combat: end_turn | 일반 act는 자동 완료. 이미 사용한 행동은 같은 인물의 act 계속으로 마무리. 자동 NPC 루프 유지 |
| combat: end | 양쪽의 전투 가능 상태를 기준으로 종료. 살아 있는 적을 두고 임의 탈출하는 규칙은 원래 end에도 없었음 |
| inventory: inspect, add, remove, equip, unequip, use, reload | 전부 유지. add는 완료한 기존 조우 보상, 새 획득 해석은 play.obtain. 장비 칸·수동 편집 유지 |
| economy: quote, sell, buy, negotiate, accept, transfer, exchange, reward | 전부 유지. 해당 화폐·저장 가격·기존 보상 사건 사용. 새 비용·환율을 임의로 정하는 기능이 아님 |
| explore: start, resume | play.explore start. 저장한 같은 장소면 복원. 기존 지도를 새 지도 구조로 강제 재생성하지 않음 |
| explore: move, inspect, interact | play.explore의 대응 명령. 구형 저장 탐험은 native-exploration, 새 장소는 adventure로 연결 |
| explore: resolve_event | 실제 조우 해결 뒤 기존 탐험의 interact/move 단계에서 내부 처리. 미해결 적을 해결했다고 간주하지 않음 |
| explore: end | play.explore end. 기존 탐험 기록 보관. 진행 중인 교전의 탈출을 대신하지 않음 |
| lifecycle: short_rest, long_rest, scene_reset, day_advance | 모두 유지. 실제 시간·휴식 사건이어야 하며 전투 중 휴식으로 우회하지 않음 |
| lifecycle: summon, dismiss_summon | 기존 정식 소환 정의와 비용 경로 유지. 등장 인물 등록만으로 소환 기술 비용을 처리한 것으로 보지 않음. **행동 소모 후 계속 안내 보강** |
| registry: ensure_actor, ensure_actors | 실제 공개·연결됨. 0.12.7의 비공개 문제는 0.13.0에서 이미 수정 |
| registry: instantiate | native는 ensure_actor의 instanceKey/templateId로 개체 생성·원형 재사용. 저수준 instantiate는 native 메타정보를 만들지 않아 예전 정의 기반 세계에서만 직접 사용 |
| registry: learn, progress | 원래 엔진에서도 별도 학습 계산이 아니라 eventGrant의 별칭. 저장된 조우 보상은 inventory.add/economy.reward가 같은 함수를 호출. 새 기술은 act에서 준비, 기술 사용 숙련은 엔진이 계산, 사건 경험치는 progress.award |
| registry: train | **다시 공개.** 저장된 training 정책만 별도 숙련 지급. 기본 valid_use 정책에서는 실제 act 사용으로 성장하며 별도 train은 변화 없음 |
| check: resolve | native에서는 공개 play.check → 보조 AI가 필요한 규칙을 한 번 선택·저장 → 내부 resolve. 예전 정의 기반 세계에서는 원래 도구도 유지 |

`combat.action`의 custom은 원래도 자유로운 수치·결과 입력이 아니라 등록된 skillId를 사용하는 경로였습니다. native의 act로 준비된 기술을 사용합니다.

## 도구 수와 설계 판단

| 모드 | 수정 전 0.17.2 | 0.17.3 |
| --- | ---: | ---: |
| 예전 정의 기반/미구축 | 11 | 11 |
| 공통 d100 | 6 | 7 |
| 얼터네이티브 헌터 | 7 | 7 |
| 로맨스 판타지/미연시 | 4 | 4 |
| 에렌샤 온라인 | 5 | 5 |

공통/헌터의 7개는 play, progress, state, inventory, economy, lifecycle, registry입니다. 도구 수보다 실제 동작 수·입력의 명확함·준비와 실행의 연결이 중요합니다. 통합 도구를 해석하는 메인 AI의 실제 성공률이나 속도는 이번 작업에서 측정하지 않았습니다.

## 보존 및 확인 범위

- NPC 자동 턴 함수는 0.17.0 및 0.17.2와 동일하며 세 호출 위치를 유지합니다.
- 사회·에렌샤 도구/엔진/지침과 효과·스킬·장비 편집 원본 파일은 이번 수정에서 바꾸지 않았습니다.
- 기존 게임·소지품·사건 기록은 유지합니다. 과거 서술에서 비용·보상을 역산하지 않습니다.
- 소스 구문, 명세 생성, 모듈 연결, 빌드와 배포 파일을 확인합니다. 브라우저·가상 플레이·모의 호스트·설치 RisuAI·API 호출은 하지 않습니다.
- 메인 AI가 필요한 도구를 아예 부르지 않는 경우는 여전히 실사용 확인이 필요합니다. 연결 복구와 모델의 호출 준수는 같은 검증이 아닙니다.
